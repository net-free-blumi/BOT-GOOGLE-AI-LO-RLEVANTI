// interactive.js - מנגנון כפתורים אינטראקטיביים ותפריט נפתח עבור וואטסאפ (Baileys)
// תומך ב-Native Flow v2 (Quick Reply / CTA / Single Select List)
// כולל Fallback בטוח לטקסט רגיל כדי להבטיח 100% מסירה לכל מכשיר

/**
 * חילוץ תגובות כפתורים מתוך מבני הודעה שונים בוואטסאפ
 */
export function extractInteractiveResponse(rawMsg) {
  if (!rawMsg) return null;
  let msg = rawMsg;

  // פירוק שכבות viewOnce או ephemeral אם קיימות
  for (let i = 0; i < 5; i++) {
    const inner =
      msg.ephemeralMessage?.message ||
      msg.viewOnceMessage?.message ||
      msg.viewOnceMessageV2?.message ||
      msg.documentWithCaptionMessage?.message ||
      msg.editedMessage?.message?.protocolMessage?.editedMessage;
    if (!inner) break;
    msg = inner;
  }

  // 1. מענה מלחיצה על כפתור רגיל (Buttons Response)
  if (msg.buttonsResponseMessage?.selectedButtonId) {
    return msg.buttonsResponseMessage.selectedButtonId.trim();
  }
  if (msg.buttonsResponseMessage?.selectedDisplayText) {
    return msg.buttonsResponseMessage.selectedDisplayText.trim();
  }

  // 2. מענה מכפתור תבנית (Template Button Reply)
  if (msg.templateButtonReplyMessage?.selectedId) {
    return msg.templateButtonReplyMessage.selectedId.trim();
  }
  if (msg.templateButtonReplyMessage?.selectedDisplayText) {
    return msg.templateButtonReplyMessage.selectedDisplayText.trim();
  }

  // 3. מענה מבחירה ברשימה נפתחת (List Response Message)
  if (msg.listResponseMessage?.singleSelectReply?.selectedRowId) {
    return msg.listResponseMessage.singleSelectReply.selectedRowId.trim();
  }

  // 4. מענה מ-Native Flow Interactive Response (הפורמט המודרני של מטא)
  if (msg.interactiveResponseMessage?.nativeFlowResponseMessage?.paramsJson) {
    try {
      const parsed = JSON.parse(msg.interactiveResponseMessage.nativeFlowResponseMessage.paramsJson);
      if (parsed.id) return String(parsed.id).trim();
      if (parsed.selected_id) return String(parsed.selected_id).trim();
      if (parsed.row_id) return String(parsed.row_id).trim();
      if (parsed.selected_row_id) return String(parsed.selected_row_id).trim();
      if (parsed.text) return String(parsed.text).trim();
    } catch (e) {}
  }

  // 5. מענה מכפתור אינטראקטיבי ישיר
  if (msg.interactiveResponseMessage?.body?.text) {
    return msg.interactiveResponseMessage.body.text.trim();
  }

  return null;
}

/**
 * שליחת הודעת כפתורים אינטראקטיבית (Native Flow + Fallback)
 * @param {object} sock - חיבור ה-Baileys
 * @param {string} jid - יעד ההודעה
 * @param {object} options - תוכן ההודעה, כפתורים ואפשרויות
 */
export async function sendInteractiveButtons(sock, jid, {
  title = "",
  body = "",
  footer = "🚕 נסיעות בוט איכותי",
  buttons = [],
  quoted = null,
}) {
  if (!sock) return null;

  // בניית כפתורי Native Flow
  const nativeButtons = buttons.map((b) => {
    if (b.type === "url" || b.url) {
      return {
        name: "cta_url",
        buttonParamsJson: JSON.stringify({
          display_text: b.text || b.displayText,
          url: b.url,
          merchant_url: b.url,
        }),
      };
    }
    if (b.type === "call" || b.phoneNumber) {
      return {
        name: "cta_call",
        buttonParamsJson: JSON.stringify({
          display_text: b.text || b.displayText,
          phone_number: b.phoneNumber,
        }),
      };
    }
    // כפתור Quick Reply רגיל - שולח תגובה טקסטואלית בעת לחיצה
    return {
      name: "quick_reply",
      buttonParamsJson: JSON.stringify({
        display_text: b.text || b.displayText,
        id: b.id || b.buttonId || b.text,
      }),
    };
  });

  // ניסיון 1: שימוש ב-generateWAMessageFromContent ו-relayMessage (פורמט Native Flow הרשמי ב-Baileys)
  try {
    const baileys = await import("@whiskeysockets/baileys").catch(() => null);
    if (baileys && baileys.generateWAMessageFromContent && baileys.proto) {
      const { generateWAMessageFromContent, proto } = baileys;

      const interactiveMessage = proto.Message.InteractiveMessage.create({
        header: title ? proto.Message.InteractiveMessage.Header.create({ title, hasMediaAttachment: false }) : undefined,
        body: proto.Message.InteractiveMessage.Body.create({ text: body }),
        footer: footer ? proto.Message.InteractiveMessage.Footer.create({ text: footer }) : undefined,
        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
          buttons: nativeButtons,
        }),
      });

      const waMsg = generateWAMessageFromContent(
        jid,
        {
          viewOnceMessage: {
            message: {
              messageContextInfo: {
                deviceListMetadata: {},
                deviceListMetadataVersion: 2,
              },
              interactiveMessage,
            },
          },
        },
        {
          userJid: sock.user?.id || sock.authState?.creds?.me?.id,
          quoted: quoted || undefined,
        }
      );

      const isGroup = typeof baileys.isJidGroup === "function"
        ? baileys.isJidGroup(jid)
        : String(jid || "").endsWith("@g.us");
      const additionalNodes = [
        {
          tag: "biz",
          attrs: {},
          content: [
            {
              tag: "interactive",
              attrs: { type: "native_flow", v: "1" },
              content: [{ tag: "native_flow", attrs: { v: "9", name: "mixed" } }],
            },
          ],
        },
      ];
      if (!isGroup) {
        additionalNodes.push({ tag: "bot", attrs: { biz_bot: "1" } }); // נדרש בצ'אט פרטי בוואטסאפ!
      }

      if (sock.relayMessage && waMsg?.key?.id) {
        await sock.relayMessage(jid, waMsg.message, { messageId: waMsg.key.id, additionalNodes });
        return waMsg;
      }
    }
  } catch (errProto) {}

  // ניסיון 2: מבנה Buttons רגיל של Baileys
  try {
    const legacyButtons = buttons.map((b, idx) => ({
      buttonId: b.id || b.buttonId || String(idx + 1),
      buttonText: { displayText: b.text || b.displayText },
      type: 1,
    }));

    const res = await sock.sendMessage(
      jid,
      {
        text: body,
        footer,
        buttons: legacyButtons,
        headerType: 1,
      },
      quoted ? { quoted } : {}
    );
    if (res?.key?.id) return res;
  } catch (errLegacy) {}

  // ניסיון 3: תבנית Hydrated Template של Baileys
  try {
    const hydratedButtons = buttons.map((b, idx) => {
      if (b.type === "url" || b.url) {
        return { index: idx + 1, urlButton: { displayText: b.text || b.displayText, url: b.url } };
      }
      return { index: idx + 1, quickReplyButton: { displayText: b.text || b.displayText, id: b.id || String(idx + 1) } };
    });

    const res = await sock.sendMessage(
      jid,
      {
        templateButtons: hydratedButtons,
        text: body,
        footer,
      },
      quoted ? { quoted } : {}
    );
    if (res?.key?.id) return res;
  } catch (errHydrated) {}

  // ניסיון 4 (Fallback בטוח תמיד): שליחת הודעת טקסט מעוצבת.
  // שים לב: body כבר כולל בתוכו את כל ההנחיות והמספרים (1, 2, ביטול / ת, תן)
  return await sock.sendMessage(jid, { text: body }, quoted ? { quoted } : {});
}

/**
 * שליחת תפריט נפתח (Interactive Single Select List)
 */
export async function sendInteractiveList(sock, jid, {
  title = "📋 תפריט פעולות",
  body = "בחר פעולה מהרשימה:",
  buttonText = "📋 פתח תפריט אפשרויות",
  sections = [],
  footer = "🚕 נסיעות בוט איכותי",
  quoted = null,
}) {
  if (!sock) return null;

  // ניסיון 1: שליחה כ-Native Flow Single Select באמצעות generateWAMessageFromContent + relayMessage + additionalNodes
  try {
    const baileys = await import("@whiskeysockets/baileys").catch(() => null);
    if (baileys && baileys.generateWAMessageFromContent && baileys.proto) {
      const { generateWAMessageFromContent, proto, isJidGroup } = baileys;

      const formattedSections = sections.map((sec) => ({
        title: String(sec.title || "").slice(0, 24),
        rows: (sec.rows || []).map((r) => ({
          header: String(r.header || "").slice(0, 24),
          title: String(r.title || "").slice(0, 24),
          description: String(r.description || "").slice(0, 72),
          id: String(r.id || r.rowId || r.title || "").slice(0, 50),
        })).slice(0, 10),
      })).slice(0, 10);

      const content = {
        viewOnceMessage: {
          message: {
            messageContextInfo: {
              deviceListMetadata: {},
              deviceListMetadataVersion: 2,
            },
            interactiveMessage: proto.Message.InteractiveMessage.create({
              header: title
                ? proto.Message.InteractiveMessage.Header.create({ title: String(title).slice(0, 24), hasMediaAttachment: false })
                : undefined,
              body: proto.Message.InteractiveMessage.Body.create({ text: body }),
              footer: footer
                ? proto.Message.InteractiveMessage.Footer.create({ text: String(footer).slice(0, 30) })
                : undefined,
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                buttons: [
                  {
                    name: "single_select",
                    buttonParamsJson: JSON.stringify({
                      title: String(buttonText || "תפריט").slice(0, 24),
                      sections: formattedSections,
                    }),
                  },
                ],
              }),
            }),
          },
        },
      };

      const waMsg = generateWAMessageFromContent(
        jid,
        content,
        {
          userJid: sock.user?.id || sock.authState?.creds?.me?.id,
          quoted: quoted || undefined,
        }
      );

      const isGroup = typeof isJidGroup === "function" ? isJidGroup(jid) : String(jid || "").endsWith("@g.us");
      const additionalNodes = [
        {
          tag: "biz",
          attrs: {},
          content: [
            {
              tag: "interactive",
              attrs: { type: "native_flow", v: "1" },
              content: [{ tag: "native_flow", attrs: { v: "9", name: "mixed" } }],
            },
          ],
        },
      ];
      if (!isGroup) {
        additionalNodes.push({ tag: "bot", attrs: { biz_bot: "1" } }); // נדרש בצ'אט פרטי בוואטסאפ!
      }

      if (sock.relayMessage && waMsg?.key?.id) {
        console.log(`📋 [תפריט נפתח] שולח תפריט Native Flow single_select ל-${jid} (ID: ${waMsg.key.id})`);
        await sock.relayMessage(jid, waMsg.message, {
          messageId: waMsg.key.id,
          additionalNodes,
        });
        return waMsg;
      }
    }
  } catch (errNativeList) {
    console.log(`ℹ️ [תפריט נפתח] Native Flow נכשל (${errNativeList?.message}), מנסה מבנה קלאסי`);
  }

  // ניסיון 2: מבנה רשימה קלאסי של Baileys
  try {
    const classicListPayload = {
      text: body,
      footer: footer,
      title: title,
      buttonText: buttonText,
      sections: sections.map((sec) => ({
        title: sec.title,
        rows: sec.rows.map((r) => ({
          title: r.title,
          description: r.description || "",
          rowId: r.id || r.rowId || r.title,
        })),
      })),
    };

    const res = await sock.sendMessage(jid, classicListPayload, quoted ? { quoted } : {});
    if (res?.key?.id) return res;
  } catch (errClassicList) {}

  // ניסיון 3 (Fallback בטוח): שליחה כטקסט
  let fallbackText = `*${title}*\n${body}\n\n`;
  sections.forEach((sec) => {
    fallbackText += `📂 *${sec.title}*\n`;
    sec.rows.forEach((r) => {
      fallbackText += `• *${r.title}* ${r.description ? `(${r.description})` : ""}\n`;
    });
    fallbackText += `\n`;
  });

  return await sock.sendMessage(jid, { text: fallbackText.trim() }, quoted ? { quoted } : {});
}

/**
 * שליחת התראת נסיעה עם כפתור תפיסה מהיר "ת" וכפתור וואטסאפ לסדרן
 */
export async function sendRideAlertWithButtons(sock, jid, rideData, quoted = null) {
  let alertBody = `${rideData.cleanedText}\n\n` +
    `📍 ${rideData.groupName}\n` +
    `👤 ${rideData.senderName} · ${rideData.senderPhone}\n\n` +
    `🚕 *לתפיסה מהירה השב:* "ת" או "תן"`;

  const buttons = [
    {
      id: "ת",
      text: "🚕 ת (תן לי)",
      type: "quick_reply",
    },
  ];

  // אם יש מספר סדרן תקין, הוספת כפתור קישור ישיר לוואטסאפ של הסדרן
  const rawPhone = String(rideData.senderPhone || "").replace(/\D/g, "");
  if (rawPhone && rawPhone.length >= 9 && rawPhone !== "זמין בקבוצה") {
    let intlPhone = rawPhone;
    if (intlPhone.startsWith("0")) intlPhone = "972" + intlPhone.slice(1);
    const waUrl = `https://wa.me/${intlPhone}`;
    alertBody += `\n💬 *וואטסאפ ישיר לסדרן:* ${waUrl}`;
    buttons.push({
      text: "💬 וואטסאפ לסדרן",
      url: waUrl,
      type: "url",
    });
  }

  return await sendInteractiveButtons(sock, jid, {
    body: alertBody,
    footer: "💡 לחץ 'ת' לתפיסה מהירה · סמן 👎 לדיווח תקלה",
    buttons,
    quoted,
  });
}

/**
 * שליחת הודעת אישור חיפוש מקבילי עם 3 כפתורים + הנחיות תגובה מפורשות בגוף ההודעה
 */
export async function sendPendingSearchConfirmationWithButtons(sock, jid, { currentSearches = [], newSearch, modeDesc = "" }) {
  const currentList = currentSearches.map((s, idx) => `${idx + 1}. ${s.displayText}`).join("\n");
  
  let body = `🔍 *יש לך כרגע חיפוש פעיל במערכת:*\n${currentList}\n\n`;
  body += `❓ *האם להוסיף את החיפוש החדש במקביל?*\n`;
  body += `📍 *חיפוש חדש:* ${newSearch.displayText} (${modeDesc})\n\n`;
  body += `*השב עכשיו במספר או מילה (או לחץ על כפתור):*\n`;
  body += `👉 *1* או *הוסף* (או *כן*) ⬅️ להוספה במקביל\n`;
  body += `👉 *2* או *החלף* ⬅️ להחליף את כל החיפושים בחדש בלבד\n`;
  body += `👉 *ביטול* (או *לא*) ⬅️ להישאר עם הקיים ללא שינוי`;

  const buttons = [
    {
      id: "1",
      text: "➕ הוסף במקביל",
      type: "quick_reply",
    },
    {
      id: "2",
      text: "🔄 החלף את הקיים",
      type: "quick_reply",
    },
    {
      id: "ביטול",
      text: "❌ ביטול",
      type: "quick_reply",
    },
  ];

  return await sendInteractiveButtons(sock, jid, {
    title: "⚡ חיפוש מקבילי - אישור",
    body,
    footer: "בחר בלחיצה על אחד הכפתורים למטה",
    buttons,
  });
}

/**
 * שליחת תפריט פעולות נפתח מלא (אינטראקטיבי)
 */
export async function sendFullInteractiveMenu(sock, jid, { activeSearches = [], describeMode }) {
  let body = `📊 *סטטוס נוכחי:* `;
  if (activeSearches.length > 0) {
    body += `🟢 ${activeSearches.length} חיפושים פעילים במקביל:\n`;
    activeSearches.forEach((s, idx) => {
      body += `${idx + 1}. ${s.displayText} (${describeMode ? describeMode(s) : s.displayText})\n`;
    });
  } else {
    body += `🔴 מופסק (תפוס / לא מחפש כרגע)\n`;
  }
  body += `\n💡 *קיצורים מהירים להקלדה:*\n` +
    `• *פנוי שמש* / *פנוי ים* / *פנוי מירון*\n` +
    `• *פנוי שמש פנימי* / *פנימי ים*\n` +
    `• *פ ים שמש* (ירושלים לבית שמש)\n` +
    `• *פ שמש ים* (בית שמש לירושלים)\n` +
    `• *תפוס* (עצירת כל החיפושים)\n\n` +
    `📋 *בחר מהתפריט הנפתח למטה או הקלד פקודה:*`;

  const sections = [
    {
      title: "🛑 שליטה ובקרה",
      rows: [
        {
          id: "תפוס",
          title: "🛑 תפוס (עצור הכל)",
          description: "מפסיק את כל החיפושים הפעילים מיד",
        },
        {
          id: "תפריט",
          title: "📋 רענן סטטוס",
          description: "מציג שוב את רשימת החיפושים הפעילים",
        },
      ],
    },
    {
      title: "🏠 חיפושים מהירים - בית שמש",
      rows: [
        {
          id: "פנוי שמש",
          title: "🚕 פנוי שמש (בתוך ומחוץ לעיר)",
          description: "נסיעות פנימיות + נסיעות מבית שמש החוצה",
        },
        {
          id: "פנוי שמש פנימי",
          title: "🔒 פנוי שמש פנימי בלבד",
          description: "רק נסיעות בתוך בית שמש",
        },
        {
          id: "פ שמש ים",
          title: "🚗 בית שמש ⬅️ ירושלים",
          description: "נסיעות מבית שמש לירושלים בלבד",
        },
      ],
    },
    {
      title: "🏛️ חיפושים מהירים - ירושלים ומירון",
      rows: [
        {
          id: "פנוי ים",
          title: "🚕 פנוי ים (בתוך ומחוץ לעיר)",
          description: "נסיעות פנימיות + מירושלים החוצה",
        },
        {
          id: "פנוי ים פנימי",
          title: "🔒 פנוי ים פנימי בלבד",
          description: "רק נסיעות בתוך ירושלים",
        },
        {
          id: "פ ים שמש",
          title: "🚗 ירושלים ⬅️ בית שמש",
          description: "נסיעות מירושלים לבית שמש בלבד",
        },
        {
          id: "פנוי מירון",
          title: "⛰️ פנוי מירון",
          description: "נסיעות מאזור מירון וצפת",
        },
      ],
    },
    {
      title: "🔗 הגדרות וסנכרון",
      rows: [
        {
          id: "חבר אותי",
          title: "🔗 קישור וואטסאפ (ווב)",
          description: "הפקת קוד צימוד לסריקת הקבוצות שלך",
        },
      ],
    },
  ];

  return await sendInteractiveList(sock, jid, {
    title: "🚕 תפריט נסיעות בוט איכותי",
    body,
    buttonText: "📋 לחץ כאן לבחירת פקודה",
    sections,
    footer: "נסיעות בוט איכותי · שליטה קלה בלחיצה אחת",
  });
}
