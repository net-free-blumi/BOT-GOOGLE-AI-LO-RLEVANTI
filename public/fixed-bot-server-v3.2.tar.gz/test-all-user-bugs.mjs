// test-all-user-bugs.mjs - בדיקה מלאה של כל התרחישים, כולל מניעת הודעות ספאם ואימות כל הפיצ'רים החדשים
import { createMatcher, normalizeText, parseDriverCommand, processDriverCommand, rideMatches, matchesAnySearch, findPlaces, extractPrice } from "./matcher.js";
import { createDeduper, isUniqueRideLink } from "./dedupe.js";
import { addOrStageUserSearch, confirmPendingSearch, cancelPendingSearch, removeUserSearchByIndex, getUserSearch, stopUserSearch } from "./users-manager.js";
import { extractInteractiveResponse, sendRideAlertWithButtons, sendPendingSearchConfirmationWithButtons, sendFullInteractiveMenu } from "./interactive.js";
import { extractDispatcherContact, buildQuotedRideMessage } from "./matcher.js";
import { formatIsraeliPhone, extractPhoneFromText } from "./matcher.js";
import { readFileSync } from "node:fs";

console.log("🧪 מתחיל בדיקות אימות מעמיקות לכל התרחישים (גרסה 3.0 - חיפושים מקבילים ובתוך/מחוץ לעיר)...\n");

const cities = JSON.parse(readFileSync(new URL("./cities.json", import.meta.url), "utf8"));
const streets = JSON.parse(readFileSync(new URL("./streets-full.json", import.meta.url), "utf8"));
const matcher = createMatcher(cities, streets);
const deduper = createDeduper(findPlaces, { windowMs: 15 * 60 * 1000 });

let passed = 0;
let total = 0;

function assert(condition, testName) {
  total++;
  if (condition) {
    passed++;
    console.log(`✅ [PASS] ${testName}`);
  } else {
    console.error(`❌ [FAIL] ${testName}`);
    process.exitCode = 1;
  }
}

const internalShemeshState = { active: true, mode: "internal", origin: "בית שמש", destination: null, displayText: "בית שמש (פנימי)" };

// ==========================================
// בדיקה 1: מניעה מוחלטת של הודעות ספאם, משטרות, פרסומות ומניות
// ==========================================
console.log("--- בדיקה 1: פסילת הודעות לא רלוונטיות (משטרות, הפצה, מניות, מאזדה) ---");

// הודעה 1 שדווחה היום (הפצה ידני בלבד)
const msgSpam1 = `0523651790\nהפצה ידני בלבד\nצרפו לקבוצות\n0523651790`;
const verdictSpam1 = matcher.rideMatches(msgSpam1, internalShemeshState);
assert(!verdictSpam1.ok, `הודעת הפצה לקבוצות נפסלת: "${verdictSpam1.reason}"`);

// הודעה 2 שדווחה היום (דיווח משטרות)
const msgPolice = `אופיר הרוש מטייל בדודיקה`;
const verdictPolice = matcher.rideMatches(msgPolice, internalShemeshState);
assert(!verdictPolice.ok, `דיווח משטרות בדודיקה נפסל: "${verdictPolice.reason}"`);

// מילים תמימות בעברית שהיו עלולות להיתפס בגלל אותיות אות-ל-אות
const innocentHebrew = [
  "מתאים לרכב מאזדה 3",
  "רכישת מניות בחברה",
  "מתקן למקרן איכותי למכירה",
  "פרסומת לחנות בגדים",
  "שלום וברכה לכולם",
  "הפנימית של האופניים פנצ'ר"
];

for (const phrase of innocentHebrew) {
  const v = matcher.rideMatches(phrase, internalShemeshState);
  assert(!v.ok, `ביטוי תמים "${phrase}" נפסל בהצלחה: "${v.reason}"`);
}

// ==========================================
// בדיקה 2: זיהוי מדויק של נסיעות פנימיות אמיתיות
// ==========================================
console.log("\n--- בדיקה 2: קבלת נסיעות פנימיות אמיתיות בכל הפורמטים ---");

// נסיעה עם חץ ומחיר מקוצר: שמש 50ש / רמה ד> ה / זמן
const v1 = matcher.rideMatches(`שמש 50ש \nרמה ד> ה \nזמן`, internalShemeshState);
assert(v1.ok, `שמש 50ש רמה ד> ה התקבלה בהצלחה: "${v1.reason}"`);

// פנימי שמש 50 / רמה ד & נעימי זמן
const v2 = matcher.rideMatches(`⚠️⚠️⚠️ פנימי שמש 50\nרמה ד & נעימי זמן\nwa.me/972552732722?text=ת+908172129+gd66wp`, internalShemeshState);
assert(v2.ok, `פנימי שמש 50 רמה ד & נעימי התקבלה בהצלחה: "${v2.reason}"`);

// פנימי שמש 50 / לב הרמה&ד
const v3 = matcher.rideMatches(`פנימי שמש 50 / לב הרמה&ד`, internalShemeshState);
assert(v3.ok, `לב הרמה&ד התקבלה בהצלחה: "${v3.reason}"`);

// חפציבה לקריה 40
const v4 = matcher.rideMatches(`חפציבה לקריה 40`, internalShemeshState);
assert(v4.ok, `חפציבה לקריה התקבלה בהצלחה: "${v4.reason}"`);

// רמה ב לרמה ג 40
const v5 = matcher.rideMatches(`רמה ב לרמה ג 40`, internalShemeshState);
assert(v5.ok, `רמה ב לרמה ג התקבלה בהצלחה: "${v5.reason}"`);

// צמצום בית שמש עם מושב סמוך
const v6 = matcher.rideMatches(`שמש צמצם \nמחסיה אדרת 80\nזמן`, { active: true, mode: "reduce", origin: "בית שמש" });
assert(v6.ok, `מחסיה אדרת 80 בצמצום התקבלה בהצלחה: "${v6.reason}"`);

// חבקוק הנביא להר מירון
const vHarMeron = matcher.rideMatches(`פ שמש 50 ש\nחבקוק הנביא להר מירון`, internalShemeshState);
assert(vHarMeron.ok, `חבקוק הנביא להר מירון התקבלה בהצלחה: "${vHarMeron.reason}"`);

// שמש פנימי הוש 80ש / כינור דוד רמה ג
const vKinor = matcher.rideMatches(`שמש פנימי הוש 80ש \n כינור דוד רמה ג`, internalShemeshState);
assert(vKinor.ok, `כינור דוד רמה ג התקבלה בהצלחה: "${vKinor.reason}"`);

// שמש 80 בתוך ד / שתי נקודות נהג עולה למסור
const vBetochD = matcher.rideMatches(`שמש 80 בתוך ד \n שתי נקודות נהג עולה למסור`, internalShemeshState);
assert(vBetochD.ok, `שמש 80 בתוך ד התקבלה בהצלחה: "${vBetochD.reason}"`);

// שמש פנימי 80 / קריה לרמה א / הלוש
const vKriyaRamaA = matcher.rideMatches(`שמש פנימי 80\nקריה לרמה א \n הלוש`, internalShemeshState);
assert(vKriyaRamaA.ok, `קריה לרמה א הלוש התקבלה בהצלחה: "${vKriyaRamaA.reason}"`);

// פ שמש 70 / רמה ה להר טוב
const vHarTov = matcher.rideMatches(`פ שמש 70 \n רמה ה להר טוב \n משלמת ביט`, internalShemeshState);
assert(vHarTov.ok, `רמה ה להר טוב התקבלה בהצלחה: "${vHarTov.reason}"`);

// פ שמש 50 / מנחם פורוש לישעי
const vYishi = matcher.rideMatches(`פ שמש 50 \n מנחם פורוש לישעי \n זמנים`, internalShemeshState);
assert(vYishi.ok, `מנחם פורוש לישעי התקבלה בהצלחה: "${vYishi.reason}"`);

// שמש פ 50ש / ד להישנה / שד' האמוראים / אור החיים דרייבוט
const vDrivebotDToYeshana = matcher.rideMatches(`שמש פ 50ש\nא 1 משלמת בביט\nד להישנה\nשד' האמוראים זמן\nwa.me/972552732722?text=ת+852897622+gd66wp\n⛔אור החיים🏅⛔ללא פון🏅`, internalShemeshState);
assert(vDrivebotDToYeshana.ok, `שמש פ 50ש ד להישנה ושד' האמוראים התקבלה בהצלחה: "${vDrivebotDToYeshana.reason}"`);

// ==========================================
// בדיקה 3: פסילת נסיעות בינעירוניות בפנימי שמש
// ==========================================
console.log("\n--- בדיקה 3: פסילת נסיעות בינעירוניות ---");

// סבא שמש 100 היוצרים (כפר סבא - בית שמש)
const vSaba = matcher.rideMatches(`סבא שמש 100\nהיוצרים\nלבקש 0504357919`, internalShemeshState);
assert(!vSaba.ok, `סבא שמש 100 נפסל מפנימי בהצלחה: "${vSaba.reason}"`);

// שמש ים 50 בדיקה
const vShemeshYam = matcher.rideMatches(`שמש ים \n 50 \n בדיקה`, internalShemeshState);
assert(!vShemeshYam.ok, `שמש ים 50 בדיקה נפסל מפנימי: "${vShemeshYam.reason}"`);

// ים שמש 50 עזרה
const vYamShemesh50 = matcher.rideMatches(`ים שמש \n 50 \n עזרה`, internalShemeshState);
assert(!vYamShemesh50.ok, `ים שמש 50 עזרה נפסל מפנימי: "${vYamShemesh50.reason}"`);

// חולון תא 100ש משלוח
const vHolon = matcher.rideMatches(`חולון תא 100ש משלוח \n שמעון אבידן`, internalShemeshState);
assert(!vHolon.ok, `חולון תא נפסל מפנימי בית שמש: "${vHolon.reason}"`);

const vKfarChabad = matcher.rideMatches(`כפר חבד שמש 200`, internalShemeshState);
assert(!vKfarChabad.ok, `כפר חב"ד נפסל: "${vKfarChabad.reason}"`);

const vSavyon = matcher.rideMatches(`סביון שמש 200`, internalShemeshState);
assert(!vSavyon.ok, `סביון נפסל: "${vSavyon.reason}"`);

const vYam = matcher.rideMatches(`ים שמש 150`, internalShemeshState);
assert(!vYam.ok, `ים שמש נפסל: "${vYam.reason}"`);

const vHighPrice = matcher.rideMatches(`שמש 180ש מקוםלאמוכר`, internalShemeshState);
assert(!vHighPrice.ok, `מחיר 180 ש"ח נפסל: "${vHighPrice.reason}"`);

// ==========================================
// בדיקה 4: פענוח מדויק של פקודות הנהג (בתוך ומחוץ לעיר מול פנימי בלבד)
// ==========================================
console.log("\n--- בדיקה 4: פענוח פקודות נהג (בתוך ומחוץ לעיר מול פנימי בלבד) ---");

// 1. עיר יחידה ללא פנימי -> בתוך ומחוץ לעיר
const pShemesh = processDriverCommand("פנוי שמש");
assert(pShemesh.mode === "city_all" && pShemesh.origin === "בית שמש", `פנוי שמש -> בתוך ומחוץ לעיר (${pShemesh.displayText})`);

const pShort = processDriverCommand("פ שמש");
assert(pShort.mode === "city_all" && pShort.origin === "בית שמש", `פ שמש -> בתוך ומחוץ לעיר (${pShort.displayText})`);

const pYam = processDriverCommand("פנוי ים");
assert(pYam.mode === "city_all" && pYam.origin === "ירושלים", `פנוי ים -> בתוך ומחוץ לעיר (${pYam.displayText})`);

const pMeron = processDriverCommand("פנוי מירון");
assert(pMeron.mode === "city_all" && pMeron.origin === "מירון", `פנוי מירון -> בתוך ומחוץ לעיר (${pMeron.displayText})`);

// 2. פקודת פנימי מפורשת -> פנימי בלבד
const pShemeshPnimi = processDriverCommand("פנוי שמש פנימי");
assert(pShemeshPnimi.mode === "internal" && pShemeshPnimi.origin === "בית שמש", `פנוי שמש פנימי -> פנימי בלבד (${pShemeshPnimi.displayText})`);

const pYamPnimi = processDriverCommand("פנוי ים פנימי");
assert(pYamPnimi.mode === "internal" && pYamPnimi.origin === "ירושלים", `פנוי ים פנימי -> פנימי בלבד (${pYamPnimi.displayText})`);

const pMeronPnimi = processDriverCommand("פנוי מירון פנימי");
assert(pMeronPnimi.mode === "internal" && pMeronPnimi.origin === "מירון", `פנוי מירון פנימי -> פנימי בלבד (${pMeronPnimi.displayText})`);

// 3. מסלול מקוצר
const pYamShemesh = processDriverCommand("פ ים שמש");
assert(pYamShemesh.mode === "route" && pYamShemesh.origin === "ירושלים" && pYamShemesh.destination === "בית שמש", `פ ים שמש -> מסלול מירושלים לבית שמש`);

const pShemeshYam = processDriverCommand("פ שמש ים");
assert(pShemeshYam.mode === "route" && pShemeshYam.origin === "בית שמש" && pShemeshYam.destination === "ירושלים", `פ שמש ים -> מסלול מבית שמש לירושלים`);

// ==========================================
// בדיקה 5: דיסלייק (👎) מוגן לחלוטין מתגובות בקבוצות
// ==========================================
console.log("\n--- בדיקה 5: בדיקת הגנת דיסלייק (👎) ---");

const BUG_REPORT_GROUP_JID = "120363402521442927@g.us";
const sentAlertsCache = new Map();
const handledReactions = new Map();
let bugReports = [];

async function handleReactionSimulation(sock, reactions, sessionContext = {}) {
  const items = Array.isArray(reactions) ? reactions : [reactions];

  for (const item of items) {
    if (!item) continue;
    const reactionText = item.reaction?.text ?? item.text ?? "";
    const targetMsgId = item.reaction?.key?.id || item.key?.id;

    if (!targetMsgId) continue;
    if (!reactionText.includes("👎")) continue;

    // התעלמות מתגובות בקבוצות (מונע דיווחי שווא בשעה 5 בבוקר!)
    const reactionChat = item.reaction?.key?.remoteJid || item.key?.remoteJid || "";
    if (String(reactionChat).endsWith("@g.us")) continue;

    // רק תגובות על הודעות שהבוט שלח
    const alertInfo = sentAlertsCache.get(targetMsgId);
    if (!alertInfo) continue;

    const dedupeKey = `${targetMsgId}|${reactionText}`;
    const nowTs = Date.now();
    if (handledReactions.has(dedupeKey) && nowTs - handledReactions.get(dedupeKey) < 30000) continue;
    handledReactions.set(dedupeKey, nowTs);

    await sock.sendMessage(BUG_REPORT_GROUP_JID, { text: `דיווח: ${alertInfo.driverPhone} על ${alertInfo.rideData.cleanedText}` });
  }
}

const mockSock = {
  async sendMessage(jid, content) {
    if (jid === BUG_REPORT_GROUP_JID) {
      bugReports.push(content.text);
    }
    return { key: { id: "mock_res" } };
  }
};

// 1. תגובת דיסלייק בקבוצה (בשעה 5 בבוקר) - חייב להתעלם לחלוטין!
bugReports = [];
await handleReactionSimulation(mockSock, [{
  key: { remoteJid: "1234567890-987654@g.us", id: "group_msg_123" },
  reaction: { text: "👎", key: { remoteJid: "1234567890-987654@g.us", id: "group_msg_123" } }
}]);
assert(bugReports.length === 0, "תגובת דיסלייק בקבוצת וואטסאפ (בשעה 5 בבוקר) אינה מדווחת לקבוצת התיקונים!");

// 2. תגובת דיסלייק על הודעה לא מוכרת בפרטי - חייב להתעלם!
bugReports = [];
await handleReactionSimulation(mockSock, [{
  key: { remoteJid: "0521111111@s.whatsapp.net", id: "unknown_msg_999" },
  reaction: { text: "👎", key: { remoteJid: "0521111111@s.whatsapp.net", id: "unknown_msg_999" } }
}]);
assert(bugReports.length === 0, "תגובת דיסלייק על הודעה פרטית שאינה נסיעה של הבוט אינה מדווחת!");

// 3. תגובת דיסלייק על נסיעה של הבוט בפרטי - מדווח לקבוצת התיקונים!
bugReports = [];
const testAlertId = "BOT_ALERT_MSG_777";
sentAlertsCache.set(testAlertId, {
  msgId: testAlertId,
  rideData: {
    cleanedText: "רמה ד לנעימי 45",
    groupName: "נסיעות שמש VIP",
  },
  driverPhone: "972539485860",
});

await handleReactionSimulation(mockSock, [{
  key: { remoteJid: "972539485860@s.whatsapp.net", id: testAlertId },
  reaction: { text: "👎", key: { remoteJid: "972539485860@s.whatsapp.net", id: testAlertId } }
}]);

assert(bugReports.length === 1, "דיסלייק אמיתי של נהג על הודעת בוט נשלח לקבוצת התיקונים");
assert(bugReports[0].includes("972539485860"), "הדו\"ח מכיל את מספר הנהג");

// ==========================================
// בדיקה 6: פורמט נקי של התראת נסיעה (בלי כותרת ובלי קווים)
// ==========================================
console.log("\n--- בדיקה 6: פורמט נקי ללא כותרת ---");

const sampleRide = {
  cleanedText: "פנימי שמש 50 / רמה ד לרמה ג",
  groupName: "נסיעות בית שמש",
  senderName: "יוסי",
  senderPhone: "0501234567"
};

const cleanAlertText = `${sampleRide.cleanedText}\n\n📍 ${sampleRide.groupName}\n👤 ${sampleRide.senderName} · ${sampleRide.senderPhone}`;

assert(!cleanAlertText.includes("נסיעה מתאימה נמצאה"), "ההתראה אינה כוללת את הכותרת המעצבנת");
assert(!cleanAlertText.includes("──────"), "ההתראה אינה כוללת קווים מפרידים מיותרים");
assert(cleanAlertText.startsWith("פנימי שמש 50"), "ההתראה מתחילה ישירות בפרטי הנסיעה");

console.log(`\n--- בדיקה 7: 9 המקרים החדשים שדווחו היום (גרסה 2.9) ---`);

// 1. נסיעות עוקבות מאותו סדרן ובאותו מחיר (הסרת כפילות שגויה של טלפון+מחיר)
const dedupKey1 = deduper.check(
  "פ שמש 50 \nהמכללה לשוטרים & ד\nזמנים\nלבקש פה \n0552683249",
  "0552683249"
);
assert(!dedupKey1.duplicate, "נסיעה 1 של סדרן 0552683249 מתקבלת");

const dedupKey2 = deduper.check(
  "פ שמש 50 \nד & קריה\nזמנים\nלבקש פה \n0552683249",
  "0552683249"
);
assert(!dedupKey2.duplicate, "נסיעה 2 של סדרן 0552683249 (ד & קריה באותו מחיר) מתקבלת ולא נחסמת ככפילות!");

const dedupKeyExact = deduper.check(
  "פ שמש 50 \nד & קריה\nזמנים\nלבקש פה \n0552683249",
  "0552683249"
);
assert(dedupKeyExact.duplicate, "שליחה חוזרת של אותה נסיעה בדיוק נחסמת ככפילות אמיתית");

// 2. רמג - קרייה
const vRmg = matcher.rideMatches(`שמש 50ש\nרמג - קרייה\n\nלבקש באישי עם תיוג המכרז!`, internalShemeshState);
assert(vRmg.ok, `רמג - קרייה התקבלה בהצלחה: "${vRmg.reason}"`);

// 3. שער בנימין אדם 50ש (נפסל מבית שמש)
const vShaarBinyamin = matcher.rideMatches(`שער בנימין אדם 50ש\n2א\nזמנים`, internalShemeshState);
assert(!vShaarBinyamin.ok, `שער בנימין אדם נפסל מבית שמש פנימי בהצלחה: "${vShaarBinyamin.reason}"`);

// 4. הודעת משטרות עם המילה "אלה" (נפסלת לחלוטין)
const msgPoliceAla = `אני מכיר בדרך כלל בשעות אלה חוזר מהאירועים לבית ונוסע משמה שאני בצפון והכל אז יודע`;
const vPoliceAla = matcher.rideMatches(msgPoliceAla, internalShemeshState);
assert(!vPoliceAla.ok, `הודעת שיחה עם המילה "אלה" נפסלת בהצלחה ולא מזוהה כאות א ל-ה`);

// 5. ג לרמה ד / אלישע הנביא
const vGleD = matcher.rideMatches(`שמש 50 \nג לרמה ד\nאלישע הנביא זמן`, internalShemeshState);
assert(vGleD.ok, `ג לרמה ד / אלישע הנביא התקבלה בהצלחה: "${vGleD.reason}"`);

// 6. הרצוג לנהרדע
const vHerzog = matcher.rideMatches(`שמש 50\nהרצוג לנהרדע\nזמן`, internalShemeshState);
assert(vHerzog.ok, `הרצוג לנהרדע התקבלה בהצלחה: "${vHerzog.reason}"`);

// 7. רוגלית שמש 80 (מושב בעמק האלה - נפסל מפנימי)
const vRoglit = matcher.rideMatches(`רוגלית שמש 80\nזמן`, internalShemeshState);
assert(!vRoglit.ok, `רוגלית (מושב אזורי) נפסל מפנימי בית שמש: "${vRoglit.reason}"`);

// 8. יואל הנביא לגפן
const vYoelGefen = matcher.rideMatches(`שמש 70\nיואל הנביא לגפן\nזמן`, internalShemeshState);
assert(vYoelGefen.ok, `יואל הנביא לגפן התקבלה בהצלחה: "${vYoelGefen.reason}"`);

// 9. חתימת תחנה: אור החיים אינו מזהם את הנסיעה
const vStationClean = matcher.rideMatches(`⚠️⚠️⚠️⚠️⚠️⚠️\nשמש פ 50ש\nא 1 משלמת בביט\nד להישנה\nשד' האמוראים זמן\nwa.me/972552732722?text=ת+852897622+gd66wp\n‎⛔אור החיים🏅⛔ללא פון🏅`, internalShemeshState);
assert(vStationClean.ok, `נסיעה עם חתימת תחנת אור החיים התקבלה נקי: "${vStationClean.reason}"`);

// 10. בדיקת לוגיקת שידור (Broadcast) - אימות שאין TypeError על sessions
const mockSessionsSummary = {
  bot: { phone: "972555081810", connected: true },
  drivers: [
    { phone: "972515157166", status: "connected" },
    { phone: "972501234567", status: "disconnected" }
  ],
  totalConnectedDrivers: 1
};
const mockApprovedUsers = [
  { phone: "972515157166", name: "נהג מחובר" },
  { phone: "972501234567", name: "נהג מנותק" }
];
const driverList = Array.isArray(mockSessionsSummary?.drivers) ? mockSessionsSummary.drivers : [];
const connectedPhones = new Set(
  driverList
    .filter((s) => s.status === "connected")
    .map((s) => s.phone)
);
const allTargets = mockApprovedUsers;
const connectedTargets = mockApprovedUsers.filter((u) => connectedPhones.has(u.phone));

assert(allTargets.length === 2, "שידור לכל הנהגים כולל את כל המאושרים");
assert(connectedTargets.length === 1 && connectedTargets[0].phone === "972515157166", "שידור למחוברים בלבד מסנן בהצלחה ללא שגיאת sessions.filter");

// ==========================================
// בדיקה 8: תרחישי הגרסה החדשה (מניעת כפילויות DriveBot ופסילת נסיעות חוץ)
// ==========================================
console.log("\n--- בדיקה 8: תרחישי הגרסה החדשה (DriveBot כפילויות ונסיעות חוץ) ---");

// 1. פסילת נסיעת חוץ מגבעתיים (למרות שמוזכרת 'רמה ד' ו'גנסין')
const vGivatayim = matcher.rideMatches(`גבעתיים שמש נחת 100\nגנסין 👈 רמה ד`, internalShemeshState);
assert(!vGivatayim.ok, `נסיעת חוץ מגבעתיים נפסלת מפנימי בית שמש: "${vGivatayim.reason}"`);

// 2. זיהוי 'רמה ד' כשלעצמו שאינו מהווה מעבר פנימי
const vRamatDAlone = matcher.detectInternalTransitionBeitShemesh("רמה ד");
assert(!vRamatDAlone, "שכונת 'רמה ד' לבדה אינה מעבר פנימי");

// 3. מניעת כפילות DriveBot בין קבוצות וואטסאפ שונות עם סיומת קישור שונה (+vkvdnj מול +hwrp6k)
const msgDriveBotGroup1 = `⚠️⚠️⚠️⚠️⚠️⚠️\nפ שמש\nעלית הנוער לרמה א\n50 זמן\nווצאפ ☚ wa.me/972552732722?text=ת+973865848+vkvdnj\nטלגרם ☚ t.me/prod_drivebot?start=t-973865848-vkvdnj\n😁 קרליבך 😁\n━━━━━━━━━━━━━━━━━━━\n⚠️ | חשוב: התחברו כבר עכשיו לפלטפורמות החדשות של דרייבוט!`;
const msgDriveBotGroup2 = `⚠️⚠️⚠️⚠️⚠️⚠️\nפ שמש\nעלית הנוער לרמה א\n50 זמן\nווצאפ ☚ wa.me/972552732722?text=ת+973865848+hwrp6k\nטלגרם ☚ t.me/prod_drivebot?start=t-973865848-hwrp6k\n😁 קרליבך 😁\n━━━━━━━━━━━━━━━━━━━\n⚠️ | חשוב: התחברו כבר עכשיו לפלטפורמות החדשות של דרייבוט!`;

const testDeduper = createDeduper(matcher.findPlaces);
const chk1 = testDeduper.check(msgDriveBotGroup1, "972539485860");
const chk2 = testDeduper.check(msgDriveBotGroup2, "972539485860");

assert(!chk1.duplicate, "הודעה ראשונה של דרייבוט מקבוצה א מאושרת כנסיעה חדשה");
assert(chk2.duplicate, `הודעה שנייה של אותה נסיעה מקבוצה ב נחסמת ככפילות: "${chk2.reason}"`);

// 4. קבלת נסיעות בית שמש פנימיות חדשות
const vAliyatHanoar = matcher.rideMatches(`פ שמש\nעלית הנוער לרמה א\n50 זמן\nלבקש פה`, internalShemeshState);
assert(vAliyatHanoar.ok, `עלית הנוער לרמה א התקבלה: "${vAliyatHanoar.reason}"`);

const vPoliceCollege = matcher.rideMatches(`פ שמש 50\nהמכללה לשוטרים & ד\nזמנים\nלבקש פה 0552683249`, internalShemeshState);
assert(vPoliceCollege.ok, `המכללה לשוטרים & ד התקבלה: "${vPoliceCollege.reason}"`);

// ==========================================
// בדיקה 9: אימות שני הפיצ'רים החדשים (גרסה 3.0)
// 1. חיפוש עיר יחידה (פנוי שמש / פנוי ים / פנוי מירון) = בתוך ומחוץ לעיר
// 2. חיפוש מקבילי מרובה לנהג + שלב אישור והוספה
// ==========================================
console.log("\n--- בדיקה 9: אימות בתוך ומחוץ לעיר + חיפושים מקביליים (גרסה 3.0) ---");

// 1. בדיקת סינון נסיעות עבור מצב 'בתוך ומחוץ לעיר' (city_all: בית שמש)
const stateCityAllShemesh = { active: true, mode: "city_all", origin: "בית שמש", destination: null, displayText: "בית שמש (בתוך ומחוץ לעיר)" };

// א. נסיעה פנימית בבית שמש מתקבלת!
const vInternalInCityAll = matcher.rideMatches(`שמש 50ש ד להישנה ושד' האמוראים`, stateCityAllShemesh);
assert(vInternalInCityAll.ok, `פנוי שמש: מקבל נסיעה פנימית בבית שמש ("${vInternalInCityAll.reason}")`);

// ב. נסיעה שיוצאת מבית שמש לירושלים מתקבלת!
const vOutboundInCityAll = matcher.rideMatches(`שמש ים 100 ש"ח יציאה מיידית`, stateCityAllShemesh);
assert(vOutboundInCityAll.ok, `פנוי שמש: מקבל נסיעה יוצאת מבית שמש ("${vOutboundInCityAll.reason}")`);

// ג. נסיעה שנכנסת לבית שמש ממקום אחר (כפר סבא או גבעתיים) נפסלת!
const vInboundInCityAll = matcher.rideMatches(`סבא שמש 100ש`, stateCityAllShemesh);
assert(!vInboundInCityAll.ok, `פנוי שמש: פוסל נסיעה נכנסת לבית שמש ("${vInboundInCityAll.reason}")`);

const vInboundGivatayim = matcher.rideMatches(`גבעתיים שמש נחת 100`, stateCityAllShemesh);
assert(!vInboundGivatayim.ok, `פנוי שמש: פוסל נסיעה מגבעתיים ("${vInboundGivatayim.reason}")`);

// 2. בדיקת סינון נסיעות עבור מצב 'פנימי בלבד' (internal: בית שמש פנימי)
const stateInternalShemesh = { active: true, mode: "internal", origin: "בית שמש", destination: null, displayText: "בית שמש (פנימי בלבד)" };

const vInternalInInternal = matcher.rideMatches(`שמש 50ש ד להישנה ושד' האמוראים`, stateInternalShemesh);
assert(vInternalInInternal.ok, `פנוי שמש פנימי: מקבל נסיעה פנימית ("${vInternalInInternal.reason}")`);

const vOutboundInInternal = matcher.rideMatches(`שמש ים 100 ש"ח`, stateInternalShemesh);
assert(!vOutboundInInternal.ok, `פנוי שמש פנימי: פוסל נסיעה יוצאת ("${vOutboundInInternal.reason}")`);

// 3. בדיקת עיר אחרת (מירון)
const stateCityAllMeron = { active: true, mode: "city_all", origin: "מירון", destination: null, displayText: "מירון (בתוך ומחוץ לעיר)" };

const vMeronInternal = matcher.rideMatches(`מירון 50 מחסום לקבר רשבי`, stateCityAllMeron);
assert(vMeronInternal.ok, `פנוי מירון: מקבל נסיעה במירון ("${vMeronInternal.reason}")`);

const vMeronOutbound = matcher.rideMatches(`מירון לצפת 80 זמן`, stateCityAllMeron);
assert(vMeronOutbound.ok, `פנוי מירון: מקבל יציאה ממירון לצפת ("${vMeronOutbound.reason}")`);

const vMeronInbound = matcher.rideMatches(`צפת למירון 80`, stateCityAllMeron);
assert(!vMeronInbound.ok, `פנוי מירון: פוסל כניסה מצפת למירון ("${vMeronInbound.reason}")`);

// 4. בדיקת מנגנון חיפושים מקביליים (Multi-Search Flow)
const testDriverPhone = "972599999999";
stopUserSearch(testDriverPhone);

// שלב א': חיפוש ראשון מופעל מיד ללא אישור
const cmd1 = processDriverCommand("פ ים שמש");
const res1 = addOrStageUserSearch(testDriverPhone, cmd1);
assert(res1.status === "activated_immediately", "חיפוש ראשון מופעל מיד ללא צורך באישור");
assert(res1.current.active && res1.current.searches.length === 1, "נשמר חיפוש 1 פעיל");

// שלב ב': הנהג שולח חיפוש שני -> נכנס להמתנה לאישור (pending_confirmation)
const cmd2 = processDriverCommand("פ ים בב");
const res2 = addOrStageUserSearch(testDriverPhone, cmd2);
assert(res2.status === "pending_confirmation", "חיפוש שני נכנס להמתנה לאישור הנהג");
assert(Boolean(res2.current.pendingSearch), "קיים pendingSearch במצב המתנה");
assert(res2.current.searches.length === 1, "הרשימה הפעילה עדיין מכילה רק את החיפוש הראשון עד אישור");

// שלב ג': הנהג מאשר להוסיף לרשימה (1 / כן / הוסף)
const resConfirm = confirmPendingSearch(testDriverPhone, false);
assert(resConfirm.success, "האישור הצליח");
assert(resConfirm.current.searches.length === 2, "כעת קיימים 2 חיפושים מקביליים פעילים ברשימה!");
assert(resConfirm.current.pendingSearch === null, "pendingSearch אופס");

// שלב ד': בדיקת סינון נסיעות מקבילי (matchesAnySearch)
const currentDriverState = getUserSearch(testDriverPhone);

// נסיעה 1: מירושלים לבית שמש -> תואמת את חיפוש 1!
const matchRide1 = matchesAnySearch(`ירושלים לבית שמש 120ש זמן`, currentDriverState);
assert(matchRide1.ok && matchRide1.matchedSearch.destination === "בית שמש", `נסיעה 1 תואמת לחיפוש הראשון: ${matchRide1.matchedSearch.displayText}`);

// נסיעה 2: מירושלים לבני ברק -> תואמת את חיפוש 2!
const matchRide2 = matchesAnySearch(`ירושלים לבני ברק 150ש מיידי`, currentDriverState);
assert(matchRide2.ok && matchRide2.matchedSearch.destination === "בני ברק", `נסיעה 2 תואמת לחיפוש השני: ${matchRide2.matchedSearch.displayText}`);

// נסיעה 3: מחיפה לטבריה -> נפסלת (לא תואמת אף אחד)
const matchRide3 = matchesAnySearch(`חיפה לטבריה 200ש`, currentDriverState);
assert(!matchRide3.ok, `נסיעה לא קשורה נפסלת במקביל: "${matchRide3.reason}"`);

// שלב ה': שליחת חיפוש זהה שכבר קיים -> מזהה כקיים
const resDuplicateSearch = addOrStageUserSearch(testDriverPhone, cmd2);
assert(resDuplicateSearch.status === "already_exists", "חיפוש כפול שכבר קיים מזוהה מיידית כקיים");

// שלב ו': הסרת חיפוש בודד לפי אינדקס (מחיקת מסלול 1)
const resRemove = removeUserSearchByIndex(testDriverPhone, 1);
assert(resRemove.success && resRemove.current.searches.length === 1, "הסרת חיפוש 1 הצליחה, נותר חיפוש יחיד פעיל");
assert(resRemove.current.searches[0].destination === "בני ברק", "החיפוש שנותר הוא ירושלים לבני ברק");

// שלב ז': שליחת חיפוש שלישי וביטולו (ביטול / בטל)
const cmd3 = processDriverCommand("פ בב שמש");
addOrStageUserSearch(testDriverPhone, cmd3);
const resCancel = cancelPendingSearch(testDriverPhone);
assert(resCancel.success && resCancel.current.pendingSearch === null, "ביטול חיפוש בהמתנה הצליח ללא פגיעה בחיפושים הקיימים");
assert(resCancel.current.searches.length === 1, "החיפוש הקיים נותר פעיל");

// שלב ח': עצירת כל החיפושים (תפוס)
stopUserSearch(testDriverPhone);
const stoppedState = getUserSearch(testDriverPhone);
assert(!stoppedState.active && stoppedState.searches.length === 0, "עצירה מלאה מכבה את כל החיפושים (מצב תפוס)");

// ==========================================
// בדיקה 7: כפתורים אינטראקטיביים, פענוח תגובות ותפריט נפתח (Native Flow + List)
// ==========================================
console.log("\n--- בדיקה 7: כפתורים אינטראקטיביים, פענוח תגובות ותפריט נפתח ---");

// 1. תגובת כפתור רגיל (Buttons Response)
const mockBtnMsg = {
  buttonsResponseMessage: {
    selectedButtonId: "1",
    selectedDisplayText: "➕ הוסף במקביל"
  }
};
assert(extractInteractiveResponse(mockBtnMsg) === "1", "חילוץ תגובה מכפתור רגיל (selectedButtonId) פועל");

// 2. תגובת כפתור תבנית (Template Button Reply)
const mockTplMsg = {
  templateButtonReplyMessage: {
    selectedId: "ת",
    selectedDisplayText: "ת"
  }
};
assert(extractInteractiveResponse(mockTplMsg) === "ת", "חילוץ תגובה מכפתור תבנית 'ת' פועל");

// 3. תגובה מתוך בחירה ברשימה נפתחת (Single Select List)
const mockListMsg = {
  listResponseMessage: {
    singleSelectReply: {
      selectedRowId: "פנוי שמש פנימי"
    }
  }
};
assert(extractInteractiveResponse(mockListMsg) === "פנוי שמש פנימי", "חילוץ תגובה מרשימה נפתחת (Single Select) פועל");

// 4. תגובה מ-Native Flow (הפורמט המודרני ביותר של וואטסאפ)
const mockNativeFlow = {
  interactiveResponseMessage: {
    nativeFlowResponseMessage: {
      paramsJson: JSON.stringify({ id: "2" })
    }
  }
};
assert(extractInteractiveResponse(mockNativeFlow) === "2", "חילוץ תגובה מ-Native Flow Interactive Response פועל");

// 5. בדיקת בניית התראת נסיעה עם כפתור תפיסה מהיר "ת" וכפתור וואטסאפ לסדרן
const mockRideData = {
  cleanedText: "שמש 50 שח\nרמה א לרמה ד",
  groupName: "דרכ\"ש",
  senderName: "יהודה",
  senderPhone: "0552683249"
};

let capturedPayload = null;
const mockInteractiveSock = {
  sendMessage: async (jid, payload) => {
    capturedPayload = payload;
    return { key: { id: "MSG_INTERACTIVE_123" } };
  }
};

await sendRideAlertWithButtons(mockInteractiveSock, "123@s.whatsapp.net", mockRideData);
assert(capturedPayload !== null, "התראת נסיעה עם כפתורים נוצרה ונשלחה לסוקט");
const hasAlertButtons = Boolean(
  capturedPayload?.viewOnceMessage?.message?.interactiveMessage?.nativeFlowMessage?.buttons ||
  capturedPayload?.buttons ||
  capturedPayload?.templateButtons
);
assert(hasAlertButtons, "התראת נסיעה מכילה כפתורים (כפתור 'ת' + כפתור וואטסאפ לסדרן)");

// 6. בדיקת בניית הודעת אישור הוספת חיפוש במקביל (3 כפתורים)
let capturedConfirm = null;
const mockSockConfirm = {
  sendMessage: async (jid, payload) => {
    capturedConfirm = payload;
    return { key: { id: "MSG_CONFIRM_123" } };
  }
};

await sendPendingSearchConfirmationWithButtons(mockSockConfirm, "123@s.whatsapp.net", {
  currentSearches: [{ displayText: "בית שמש" }],
  newSearch: { displayText: "ירושלים לבית שמש" },
  modeDesc: "נסיעות מירושלים לבית שמש"
});
const confirmButtons =
  capturedConfirm?.viewOnceMessage?.message?.interactiveMessage?.nativeFlowMessage?.buttons ||
  capturedConfirm?.buttons ||
  capturedConfirm?.templateButtons;
assert(Array.isArray(confirmButtons) && confirmButtons.length === 3, "שאלת אישור חיפוש מכילה 3 כפתורים (הוסף, החלף, ביטול)");

// 7. בדיקת תפריט פעולות נפתח מלא (List Menu)
let capturedMenu = null;
const mockSockMenu = {
  sendMessage: async (jid, payload) => {
    capturedMenu = payload;
    return { key: { id: "MSG_MENU_123" } };
  },
  relayMessage: async (jid, message, options) => {
    capturedMenu = message;
    return { key: { id: "MSG_MENU_123" } };
  }
};

await sendFullInteractiveMenu(mockSockMenu, "123@s.whatsapp.net", {
  activeSearches: [{ displayText: "בית שמש", mode: "city_all", origin: "בית שמש" }],
  describeMode: () => "בתוך ומחוץ לעיר"
});
const menuSections =
  capturedMenu?.viewOnceMessage?.message?.interactiveMessage?.nativeFlowMessage?.buttons ||
  capturedMenu?.interactiveMessage?.nativeFlowMessage?.buttons ||
  capturedMenu?.sections;
assert(Boolean(menuSections), "תפריט נפתח מלא נוצר בהצלחה עם אפשרויות בחירה נוחות");

// ==========================================
// בדיקה 8: תרחישי הדיווח האחרון (בידוד צפת מבית שמש + נחל משמר ורחוב ברוש)
// ==========================================
console.log("\n--- בדיקה 8: בידוד צפת מבית שמש + זיהוי נחל משמר וברוש ---");

// תרחיש א': נהג שמחפש צפת (בתוך ומחוץ לעיר) לא מקבל נסיעות פנימיות מבית שמש!
const tzfatDriverState = {
  active: true,
  searches: [
    { mode: "city_all", origin: "צפת", destination: null, displayText: "צפת (בתוך ומחוץ לעיר)" },
    { mode: "route", origin: "ירושלים", destination: "בית שמש", displayText: "ירושלים ⬅️ בית שמש" },
    { mode: "route", origin: "נתב\"ג", destination: "ירושלים", displayText: "נתב\"ג ⬅️ ירושלים" }
  ]
};

const rideShemeshBug1 = "פנימי שמש 50\nוותיקה לרמה ד\nהגפן זמן";
const vTzfat1 = matchesAnySearch(rideShemeshBug1, tzfatDriverState);
assert(!vTzfat1.ok, `נסיעת בית שמש פנימי נפסלת מחיפוש צפת: "${vTzfat1.reason}"`);

const rideShemeshBug2 = "שמש פנימי ברוש - לד גגון מיניק וכו' 120\n0542086154";
const vTzfat2 = matchesAnySearch(rideShemeshBug2, tzfatDriverState);
assert(!vTzfat2.ok, `נסיעת ברוש-לד נפסלת מחיפוש צפת: "${vTzfat2.reason}"`);

// תרחיש ב': נהג שמחפש בית שמש (פנימי) מקבל את נחל משמר לברכיה!
const shemeshInternalState = {
  active: true,
  searches: [{ mode: "internal", origin: "בית שמש", destination: null, displayText: "בית שמש (פנימי)" }]
};

const rideMishmarText = `שמש 50ש\nנחל משמר לברכיה זמן\nווצאפ ☚ wa.me/972552732722?text=ת+680229719+gd66wp\n🎩8080* - ללא פון 🎩`;
const vMishmar = matchesAnySearch(rideMishmarText, shemeshInternalState);
assert(vMishmar.ok, `נסיעת נחל משמר לברכיה מתקבלת בהצלחה בבית שמש פנימי: "${vMishmar.reason}"`);

// תרחיש ג': נסיעת ברוש - לד (מיניק 120) מתקבלת בבית שמש פנימי
const vBroshShemesh = matchesAnySearch(rideShemeshBug2, shemeshInternalState);
assert(vBroshShemesh.ok, `נסיעת ברוש - לד מתקבלת בהצלחה בבית שמש פנימי: "${vBroshShemesh.reason}"`);

// ==========================================
// בדיקה 9: בידוד נסיעות בני ברק מירושלים + חילוץ טלפון סדרן לתפיסת "תן"
// ==========================================
console.log("\n--- בדיקה 9: בידוד בני ברק מירושלים + תפיסה אוטומטית 'תן' ---");

// מקרה הדיווח: בב 70 / שבטי ישראל לרבי עקיבא / לבקש פה 0507787427
const bbRideText = `בב 70 \nשבטי ישראל לרבי עקיבא\nלבקש פה 0507787427`;

const jerusalemDriverState = {
  active: true,
  searches: [{ mode: "city_all", origin: "ירושלים", destination: null, displayText: "ירושלים (בתוך ומחוץ לעיר)" }]
};

const bneiBrakDriverState = {
  active: true,
  searches: [{ mode: "city_all", origin: "בני ברק", destination: null, displayText: "בני ברק (בתוך ומחוץ לעיר)" }]
};

// 1. נהג שמחפש ירושלים לא מקבל נסיעה פנימית מבני ברק!
const vJlm = matchesAnySearch(bbRideText, jerusalemDriverState);
assert(!vJlm.ok, `נסיעת בני ברק (בב 70) נפסלת מחיפוש ירושלים: "${vJlm.reason}"`);

// 2. נהג שמחפש בני ברק מקבל אותה
const vBb = matchesAnySearch(bbRideText, bneiBrakDriverState);
assert(vBb.ok, `נסיעת בני ברק מתקבלת בהצלחה בחיפוש בני ברק: "${vBb.reason}"`);

// 3. חילוץ טלפון סדרן מתוך תוכן ההודעה ("לבקש פה 0507787427")
const extractedPhone1 = extractDispatcherContact({
  rawText: bbRideText,
  senderPhone: "972526753681"
});
assert(extractedPhone1 === "972507787427" || extractedPhone1 === "0507787427", `חילוץ טלפון סדרן ישיר מתוכן ההודעה: ${extractedPhone1}`);

// 4. חילוץ טלפון סדרן מנסיעת מיניק ("לבקש 0542086154")
const extractedPhone2 = extractDispatcherContact({
  rawText: "שמש פנימי ברוש - לד גגון מיניק וכו' 120\nזמנים\nלבקש\n👇👇👇👇👇👇\n0542086154",
  senderPhone: "זמין בקבוצה"
});
assert(extractedPhone2 === "972542086154" || extractedPhone2 === "0542086154", `חילוץ טלפון סדרן מנסיעת מיניק: ${extractedPhone2}`);

// 5. אימות פורמט נקי של ההתראה (ללא פוטר של תפיסה מהירה/חיוג)
const sampleCleanAlert = `${bbRideText}\n\n📍 קבוצת נסיעות\n👤 סדרן · 0507787427`;
assert(!sampleCleanAlert.includes("לתפיסה מהירה"), "ההתראה נקייה מלשונית תפיסה מהירה");
assert(!sampleCleanAlert.includes("חיוג מהיר"), "ההתראה נקייה מלשונית חיוג מהיר");

// 6. אימות מבנה הציטוט הרשמי של הנסיעה (לתגובה בקבוצה ולתגובה אישית לסדרן)
const testAlertInfo = {
  msgId: "BOT_ALERT_12345",
  rawText: bbRideText,
  groupName: "⚜️ סוס ורוכבו ⚜️",
  groupJid: "120363000000000000@g.us",
  senderName: "אהרון",
  senderPhone: "972548362633",
  senderJid: "972548362633@s.whatsapp.net",
  originalMsgKey: {
    id: "ORIG_MSG_99999",
    remoteJid: "120363000000000000@g.us",
    participant: "972548362633@s.whatsapp.net",
    fromMe: false,
  },
  originalMessage: {
    conversation: bbRideText,
  }
};

const quoteObj = buildQuotedRideMessage(testAlertInfo);
assert(quoteObj && typeof quoteObj === "object", "אובייקט ציטוט נוצר בהצלחה");
assert(quoteObj.key.remoteJid === "120363000000000000@g.us", "אובייקט הציטוט מקושר לקבוצה המקורית");
assert(quoteObj.key.id === "ORIG_MSG_99999", "אובייקט הציטוט מפנה ל-ID של הודעת הסדרן המקורית");
assert(quoteObj.key.participant === "972548362633@s.whatsapp.net", "אובייקט הציטוט מציין את הסדרן המקורי כמשתתף");
assert(quoteObj.message?.conversation === bbRideText, "אובייקט הציטוט מכיל את תוכן הודעת הנסיעה המקורית");

console.log("\n--- בדיקה 10: תיקון דיסלייקים מקיף (נסיעות נכנסות, הר טוב, עין כרם, מנחם משיב, וכלל הערים) ---");

// באג 1: יסודות שמש (נסיעה נכנסת לבית שמש)
const yesodotRide = "⚠️⚠️⚠️⚠️⚠️⚠️\nיסודות שמש 150 מיידי\nבית חנן זמן";
const verdictYesodot = rideMatches(yesodotRide, { mode: "city_all", origin: "בית שמש" });
assert(!verdictYesodot.ok, `יסודות שמש נפסל בהצלחה מחיפוש בית שמש (נסיעה נכנסת): "${verdictYesodot.reason}"`);

// באג 2: עיכ שמש (נסיעה נכנסת מעין כרם לבית שמש)
const einKeremRide = "עיכ שמש 150\nזמנים\n\nלבקש ב.\n\n0528101833";
const verdictEinKerem = rideMatches(einKeremRide, { mode: "city_all", origin: "בית שמש" });
assert(!verdictEinKerem.ok, `עיכ שמש נפסל בהצלחה מחיפוש בית שמש (נסיעה נכנסת): "${verdictEinKerem.reason}"`);

// באג 3: כפר קאסם שמש (נסיעה נכנסת מכפר קאסם לבית שמש)
const kfarQasimRide = "⚠️⚠️⚠️⚠️⚠️⚠️\nכפר קאסם שמש 240\nמידי";
const verdictKfarQasim = rideMatches(kfarQasimRide, { mode: "city_all", origin: "בית שמש" });
assert(!verdictKfarQasim.ok, `כפר קאסם שמש נפסל בהצלחה מחיפוש בית שמש (נסיעה נכנסת): "${verdictKfarQasim.reason}"`);

// באג 4: שמש הר טוב 70 / מלאכי הנביא (נסיעה פנימית בבית שמש)
const harTuvRide = "שמש הר טוב 70\nמלאכי הנביא זמן";
const verdictHarTuv = rideMatches(harTuvRide, { mode: "internal", origin: "בית שמש" });
assert(verdictHarTuv.ok, `שמש הר טוב לרחוב מלאכי הנביא מתקבל בהצלחה בפנימי: "${verdictHarTuv.reason}"`);

// באג 5: ים בב 250 / מנחם משיב (נסיעה מירושלים לבני ברק - אסור שתתאים לבית שמש)
const menachemRide = "⚠️⚠️⚠️⚠️⚠️⚠️\nים בב 250\nמנחם משיב";
const verdictMenachem = rideMatches(menachemRide, { mode: "city_all", origin: "בית שמש" });
assert(!verdictMenachem.ok, `נסיעת מנחם משיב (ירושלים-בני ברק) נפסלת בהצלחה מבית שמש ללא זיהוי שגוי של נחם: "${verdictMenachem.reason}"`);

// באג 6: נווה דניאל & שמש 170 (נסיעה נכנסת מגוש עציון לבית שמש)
const neveDanielRide = "⚠️⚠️⚠️⚠️⚠️⚠️\nנווה דניאל & שמש 170\nזמןןןן";
const verdictNeveDaniel = rideMatches(neveDanielRide, { mode: "city_all", origin: "בית שמש" });
assert(!verdictNeveDaniel.ok, `נווה דניאל & שמש נפסל בהצלחה מחיפוש בית שמש (נסיעה נכנסת): "${verdictNeveDaniel.reason}"`);

// אימות הכלליות של החוק על כלל ערי ישראל:
// 1. חיפה לטבריה - נפסל מטבריה (נכנסת), מתקבל בחיפה (יוצאת)
const haifaTiberias = "חיפה טבריה 200";
const vTib = rideMatches(haifaTiberias, { mode: "city_all", origin: "טבריה" });
assert(!vTib.ok, `חיפה טבריה נפסל מנהג בטבריה: "${vTib.reason}"`);
const vHaifa = rideMatches(haifaTiberias, { mode: "city_all", origin: "חיפה" });
assert(vHaifa.ok, `חיפה טבריה מתקבל לנהג בחיפה: "${vHaifa.reason}"`);

// 2. צפת למירון - נפסל ממירון (נכנסת), מתקבל בצפת (יוצאת)
const safedMeron = "צפת מירון 70";
const vMeron = rideMatches(safedMeron, { mode: "city_all", origin: "מירון" });
assert(!vMeron.ok, `צפת מירון נפסל מנהג במירון: "${vMeron.reason}"`);
const vSafed = rideMatches(safedMeron, { mode: "city_all", origin: "צפת" });
assert(vSafed.ok, `צפת מירון מתקבל לנהג בצפת: "${vSafed.reason}"`);

console.log("\n--- בדיקה 11: אימות נסיעות ערוץ טלגרם ופורמט דרייבוט (צילום מסך משתמש) ---");

// בדיקה 1: נסיעת "ים שמש 170" מערוץ "כל הנסיעות" של דרייבוט מתקבלת עבור נהג שמחפש בית שמש
const tgChannelRide = "כל הנסיעות\nים שמש 170\nשערי רווחה\nתחנה בתוספת\nפאגז גדול\nסטיישן\n* 🎩 ללא פון - 8080 🎩\n◄ לוי סדרן\ndrivebot.co.il";
const tgVerdict = rideMatches(tgChannelRide, { mode: "city_all", origin: "בית שמש" }, "כל הנסיעות");
assert(tgVerdict.ok, `נסיעת ים שמש 170 מתקבלת בהצלחה בחיפוש בית שמש: "${tgVerdict.reason}"`);

// בדיקה 3: נסיעת "עינב נתניה 150" מצילום המסך של ערוץ "כל הנסיעות"
const einavRide = "אפשר זמנים ארוכים\nעינב נתניה 150 ש\nזמנים נוסעת אחת\nמוניות אוטוטו - ללא פון\ndrivebot.co.il";
const einavVerdict = rideMatches(einavRide, { mode: "city_all", origin: "עינב" }, "כל הנסיעות");
assert(einavVerdict.ok, `נסיעת עינב נתניה 150 מתקבלת בהצלחה בחיפוש עינב: "${einavVerdict.reason}"`);

const mockUpdateContainer = {
  className: "UpdatesCombined",
  updates: [
    { className: "UpdateNewChannelMessage", message: { id: 101, message: "ים שמש 170" } },
    { className: "UpdateNewChannelMessage", message: { id: 102, message: "עינב נתניה 150 ש" } }
  ]
};
const extractedMsgs = (mockUpdateContainer.updates || []).map(u => u.message).filter(Boolean);
assert(extractedMsgs.length === 2 && extractedMsgs[0].id === 101 && extractedMsgs[1].id === 102, "חילוץ הודעות מתוך עדכון משולב של טלגרם (UpdatesCombined) הצליח");

console.log("\n--- בדיקה 12: אימות חילוץ מספר סדרן, עיצוב טלפונים ושמות קבוצות ---");

// 1. חילוץ מספר טלפון מקישור wa.me
const waMeText = "שמש פ 50ש\nד להישנה\nשד' האמוראים\nwa.me/972552732722?text=ת+852897622\nאור החיים";
const pWaMe = extractPhoneFromText(waMeText);
assert(pWaMe === "0552732722", `חילוץ טלפון סדרן מקישור wa.me הצליח: ${pWaMe}`);

// 2. חילוץ מספר עם מילת הקשר (סדרן/טלפון/לפרטים)
const ctxText = "שמש ים 150 רמה ד לגבעת שאול\nסדרן: 054-8556165";
const pCtx = extractPhoneFromText(ctxText);
assert(pCtx === "0548556165", `חילוץ טלפון סדרן עם מילת הקשר הצליח: ${pCtx}`);

// 3. חילוץ מספר ישראלי ישיר בטקסט
const directText = "ים שמש 170 שערי רווחה 0528786639 זמין עכשיו";
const pDirect = extractPhoneFromText(directText);
assert(pDirect === "0528786639", `חילוץ מספר ישראלי ישיר הצליח: ${pDirect}`);

// 4. חילוץ מספר עם קידומת בינלאומית +972
const intlText = "עינב נתניה 150 +972 53-948-5860 זמנים נוסעת אחת";
const pIntl = extractPhoneFromText(intlText);
assert(pIntl === "0539485860", `חילוץ מספר עם קידומת בינלאומית +972 הצליח: ${pIntl}`);

// 5. עיצוב מספר ישראלי 05X-XXXXXXX
assert(formatIsraeliPhone("0548556165") === "054-8556165", "עיצוב 0548556165 ל-054-8556165 הצליח");
assert(formatIsraeliPhone("972528786639") === "052-8786639", "עיצוב 972528786639 ל-052-8786639 הצליח");
assert(formatIsraeliPhone("053-9485860") === "053-9485860", "עיצוב מספר שכבר מעוצב נשמר תקין");

console.log(`\n🎉 סיום: ${passed}/${total} בדיקות עברו בהצלחה מושלמת!`);





